Projekt: Omega – Program na sledování stavu počítače
Autor: Zdeněk Šejvl
Email: sejvl.zdenek@seznam.cz
Školní projekt: SPŠE Ječná

Instalace programu:

!!! Pozor !!!
	- nejprve si zkontroluj zda ti windows či jiný systém nezablokoval funkce/soubory:
		- OpenHardwareMonitorLib.dll 
			- ve složce \bin\vendor\OpenHardwareMonitor
		- a zda nemáš zablokovaný exe soubor
	- odblokuješ je pomocí toho, že najedeš na ně myší, klikneš pravý tlačítko -> vlastnosti
		a dole zaškrtneš odblokovat (povolit) a potom jen ok

2 možnosti zapnuti:

   1.možnost => exe soubor: 	
	- Pozor aplikace se nemusí vykreslit celá !!! kvůli exe souboru (baguje se)
		- kvůli windows defendr se ti aplikace nemusí zapnout vůbec -> windows to zablokuje
	- Zapnutí .exe souboru by mělo být normální jako káždá jina aplikace.
	- exe soubor najdete ve složce dist/main/main.exe 
	- na aplikace.exe staci dvakrát kliknout (otevřít ho) a po 3-5 sekundách se aplikace naběhne

   2.možnost, když nefunguje exe soubor => přes cmd:
	- musí se nainstalovat python 3, nejlépe verze 3.8 a starší
		- nhttps://www.python.org/downloads/
	- dále se musí doinstalovat tyto knihovny v konzoli:
		- pip install google
		- pip install beautifulsoup4
		- pip install tk
		- pip install wmi
                - pip install platform - nemusí se instalovat, když je novější verze pythonu
     		- pip install psutil
		- pip3 install tabulate
		- pip install Pillow
		- pip install gputil
    		- pip install pythonnet (kdyby toto hlásillo chybu stáhni z webu https://www.lfd.uci.edu/~gohlke/pythonlibs/#pythonnet -> pythonnet‑2.5.2‑cp39‑cp39‑win_amd64.whl
      			a pak zadej pip install C:\Users\User\Downloads\pythonnet‑2.5.2‑cp39‑cp39‑win_amd64.whl. Je to způsobený tím, že pythonnet zatím nepodporuje verze pythonu 3.9 a novější.Nebo si stáhni starší verzi pythonu (3.8 a starší)
		- druhá varianta jak nainstalovat pythonnet je daleko lehčí, stačí napsat toto: pip install --pre pythonnet

        - Postup zapnutí programu přes konzoli:
	- program lze otevřít přes cmd.exe (command shell v operačním systému Microsoft Windows)
		- doporučuje se spouštět s oprávněním správce. To znamená že když otevírám cmd, tak tam musím zakliknout: Spusti jako správce (jinak nebudou přístupný některé funkce)
	- pak stačí v konzoli napsat cestu do složky Omega (cd "cesta"), pak už by se apk měla naběhnout (cmd: cesta_k_souboru> python ./bin/main.py)

		- jestli si chceš vybuldit exe soubor, nainstaluj si všechny potřebné moduly a jěšte toto:
			- pip install pyinstaller 
		- a pak klikni na buildWin.bat


