﻿namespace Poker
{
  //rozhraní decku
    public interface IDeck
    {
       // pocet karet ktere jsou ve frontě
        int CardsInQueue { get; }
       //vrátí dalsí kartu na řadě
        Card GetNextCard();
        // nahledne na další kartu
        Card Peek();
        // vytvoří nové karty a zamíchá
        void NewDeck();
    }
}
