﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poker
{
   //výhra, násobí se podle dosažené kobinace(multiplier)
    public class Prize
    {
        public string Name { get; set; }
        public int Multiplier { get; set; }
        public Prize() { }
    }
}
