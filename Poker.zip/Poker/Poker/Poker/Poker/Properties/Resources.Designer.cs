﻿

namespace Poker.Properties {
    using System;
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Resources.Tools.StronglyTypedResourceBuilder", "15.0.0.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    internal class Resources {
        
        private static global::System.Resources.ResourceManager resourceMan;
        
        private static global::System.Globalization.CultureInfo resourceCulture;
        
        [global::System.Diagnostics.CodeAnalysis.SuppressMessageAttribute("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        internal Resources() {
        }
        
        [global::System.ComponentModel.EditorBrowsableAttribute(global::System.ComponentModel.EditorBrowsableState.Advanced)]
        internal static global::System.Resources.ResourceManager ResourceManager {
            get {
                if (object.ReferenceEquals(resourceMan, null)) {
                    global::System.Resources.ResourceManager temp = new global::System.Resources.ResourceManager("Poker.Properties.Resources", typeof(Resources).Assembly);
                    resourceMan = temp;
                }
                return resourceMan;
            }
        }
       
        [global::System.ComponentModel.EditorBrowsableAttribute(global::System.ComponentModel.EditorBrowsableState.Advanced)]
        internal static global::System.Globalization.CultureInfo Culture {
            get {
                return resourceCulture;
            }
            set {
                resourceCulture = value;
            }
        }
       
        internal static System.Drawing.Bitmap _10C {
            get {
                object obj = ResourceManager.GetObject("_10C", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap _10D {
            get {
                object obj = ResourceManager.GetObject("_10D", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap _10H {
            get {
                object obj = ResourceManager.GetObject("_10H", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap _10S {
            get {
                object obj = ResourceManager.GetObject("_10S", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
      
        internal static System.Drawing.Bitmap _2C {
            get {
                object obj = ResourceManager.GetObject("_2C", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap _2D {
            get {
                object obj = ResourceManager.GetObject("_2D", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap _2H {
            get {
                object obj = ResourceManager.GetObject("_2H", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap _2S {
            get {
                object obj = ResourceManager.GetObject("_2S", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap _3C {
            get {
                object obj = ResourceManager.GetObject("_3C", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap _3D {
            get {
                object obj = ResourceManager.GetObject("_3D", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap _3H {
            get {
                object obj = ResourceManager.GetObject("_3H", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap _3S {
            get {
                object obj = ResourceManager.GetObject("_3S", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap _4C {
            get {
                object obj = ResourceManager.GetObject("_4C", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap _4D {
            get {
                object obj = ResourceManager.GetObject("_4D", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap _4H {
            get {
                object obj = ResourceManager.GetObject("_4H", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap _4S {
            get {
                object obj = ResourceManager.GetObject("_4S", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap _5C {
            get {
                object obj = ResourceManager.GetObject("_5C", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap _5D {
            get {
                object obj = ResourceManager.GetObject("_5D", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
               
        internal static System.Drawing.Bitmap _5H {
            get {
                object obj = ResourceManager.GetObject("_5H", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap _5S {
            get {
                object obj = ResourceManager.GetObject("_5S", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap _6C {
            get {
                object obj = ResourceManager.GetObject("_6C", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap _6D {
            get {
                object obj = ResourceManager.GetObject("_6D", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap _6H {
            get {
                object obj = ResourceManager.GetObject("_6H", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap _6S {
            get {
                object obj = ResourceManager.GetObject("_6S", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap _7C {
            get {
                object obj = ResourceManager.GetObject("_7C", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap _7D {
            get {
                object obj = ResourceManager.GetObject("_7D", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap _7H {
            get {
                object obj = ResourceManager.GetObject("_7H", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap _7S {
            get {
                object obj = ResourceManager.GetObject("_7S", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap _8C {
            get {
                object obj = ResourceManager.GetObject("_8C", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap _8D {
            get {
                object obj = ResourceManager.GetObject("_8D", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap _8H {
            get {
                object obj = ResourceManager.GetObject("_8H", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap _8S {
            get {
                object obj = ResourceManager.GetObject("_8S", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap _9C {
            get {
                object obj = ResourceManager.GetObject("_9C", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap _9D {
            get {
                object obj = ResourceManager.GetObject("_9D", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap _9H {
            get {
                object obj = ResourceManager.GetObject("_9H", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap _9S {
            get {
                object obj = ResourceManager.GetObject("_9S", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap AC {
            get {
                object obj = ResourceManager.GetObject("AC", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap AD {
            get {
                object obj = ResourceManager.GetObject("AD", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap AH {
            get {
                object obj = ResourceManager.GetObject("AH", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap AS {
            get {
                object obj = ResourceManager.GetObject("AS", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap back {
            get {
                object obj = ResourceManager.GetObject("back", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap JC {
            get {
                object obj = ResourceManager.GetObject("JC", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap JD {
            get {
                object obj = ResourceManager.GetObject("JD", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap JH {
            get {
                object obj = ResourceManager.GetObject("JH", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
       
        //vyhledá zdroj typu System.Drawing.Bitmap.
        
        internal static System.Drawing.Bitmap JS {
            get {
                object obj = ResourceManager.GetObject("JS", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap KC {
            get {
                object obj = ResourceManager.GetObject("KC", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap KD {
            get {
                object obj = ResourceManager.GetObject("KD", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap KH {
            get {
                object obj = ResourceManager.GetObject("KH", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap KS {
            get {
                object obj = ResourceManager.GetObject("KS", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap QC {
            get {
                object obj = ResourceManager.GetObject("QC", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        internal static System.Drawing.Bitmap QD {
            get {
                object obj = ResourceManager.GetObject("QD", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }

        internal static System.Drawing.Bitmap QH {
            get {
                object obj = ResourceManager.GetObject("QH", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
       
        internal static System.Drawing.Bitmap QS {
            get {
                object obj = ResourceManager.GetObject("QS", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
    }
}
