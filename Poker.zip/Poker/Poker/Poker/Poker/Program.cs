﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Poker
{
    static class Program
    {
       // vstupní bod aplikace
        [STAThread]
        static void Main()
        {   
            //povolí vizuální styly a založí novou hru
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new GameBoard());
        }
    }
}
