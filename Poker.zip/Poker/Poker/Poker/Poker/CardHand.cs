﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Poker
{
    // třída na vaše karty které máte "v ruce"
    public partial class CardHand : UserControl
    {
        private IDeck _deck;
        private List<Card> _hand = new List<Card>();
        private bool _isInitialized = false;
      
        //inicializace
        public bool IsInitialized
        {
            get { return _isInitialized; }
        }
        private int _stage = 0;
        public bool EndStage
        {
            get { return _stage == 1; }
        }
        //začatek kola
        protected virtual void OnStartOfHand()
        {
            StartOfHand?.Invoke(this, EventArgs.Empty);
        }
       
        //metoda invoke - vyhledává nadřazený řetězec ovládacího prvku, pokud neexistuje vyhodí výjimku
        public event EventHandler StartOfHand;
        protected virtual void OnHandDealt()
        {
            HandDealt?.Invoke(this, EventArgs.Empty);
        }
        
        public event EventHandler HandDealt;
       
        // panely jsou zaneprázdněné - hra běží
        public bool IsBusy
        {
            get
            {
                return cardPanel1.IsBusy && cardPanel2.IsBusy && cardPanel3.IsBusy && cardPanel4.IsBusy && cardPanel5.IsBusy;
            }
        }
        //konec kola
        protected virtual void OnHandComplete(HandCompleteEventArgs e)
        {
            HandComplete?.Invoke(this, e);
        }
        //zpracovává data události
        public event EventHandler<HandCompleteEventArgs> HandComplete;
        public CardHand()
        {
            InitializeComponent();
        }

        //načtení
        private void CardHand_Load(object sender, EventArgs e)
        {
        }
        
        //inicializace
        public void Initialize(IDeck deck)
        {
            _deck = deck;
            _hand.Clear();
            OnStartOfHand();
            for (int i = 0; i < 5; i++)
            {
                _hand.Add(_deck.GetNextCard());
                Control[] panels = Controls.Find($"cardPanel{i + 1}", true);
                if (panels.Length > 0)
                {
                    ((CardPanel)panels[0]).SetCardObject(_hand[i]);
                }
            }
            _isInitialized = true;
            OnHandDealt();
        }
        
        public void Deal()
        {
            if (_isInitialized)
            {
                if (_stage == 0)
                {
                    _stage = 1;
                    // pokud zbývá málo karet udělá nový balík                       
                    if (_deck.CardsInQueue < 5)
                    {
                        _deck.NewDeck();
                    }
                    for (int i = 0; i < 5; i++)
                    {
                        if (!_hand[i].Held)
                        {
                            _hand[i] = _deck.GetNextCard();
                            Control[] panels = Controls.Find($"cardPanel{i + 1}", true);
                            if (panels.Length > 0)
                            {
                                ((CardPanel)panels[0]).SetCardObject(_hand[i]);
                            }
                        }
                    }
                    OnHandDealt();
                    OnHandComplete(new HandCompleteEventArgs { Hand = _hand });
                }
                else
                {
                    OnStartOfHand();
                    _hand.Clear();
                    if (_deck.CardsInQueue < 5)
                    {
                        _deck.NewDeck();
                    }
                    // ziskej 5 karet
                    for (int i = 0; i < 5; i++)
                    {
                        _hand.Add(_deck.GetNextCard());
                        Control[] panels = Controls.Find($"cardPanel{i + 1}", true);
                        if (panels.Length > 0)
                        {
                            ((CardPanel)panels[0]).SetCardObject(_hand[i]);
                        }
                    }
                    OnHandDealt();
                    _stage = 0;
                }
            }
        }
        //uzamkne kartu
        public void HoldCard(int position)
        {
            if (_isInitialized && _stage == 0)
            {
                switch (position)
                {
                    case 1:
                        cardPanel1.CardHeld = !cardPanel1.CardHeld;
                        break;
                    case 2:
                        cardPanel2.CardHeld = !cardPanel2.CardHeld;
                        break;
                    case 3:
                        cardPanel3.CardHeld = !cardPanel3.CardHeld;
                        break;
                    case 4:
                        cardPanel4.CardHeld = !cardPanel4.CardHeld;
                        break;
                    case 5:
                        cardPanel5.CardHeld = !cardPanel5.CardHeld;
                        break;
                }
            }
        }
       
        public class HandCompleteEventArgs : EventArgs
        {
            // list karet aktualne na displayi
            public List<Card> Hand { get; set; }
            public HandCompleteEventArgs() { }
        }
    }
}
