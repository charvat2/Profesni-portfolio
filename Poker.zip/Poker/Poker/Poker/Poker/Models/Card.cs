﻿using System.Drawing;

namespace Poker
{
   //třída karet
    public class Card
    {
       
        public string Name { get; set; }
       // čísla karet 2 = 2, 14 = eso
        public int Ordinal { get; set; }
       
        public Suit Suit { get; set; }
       //obrázky karet
        public Image Image { get; set; }
        private bool _held;
       
        public bool Held
        {
            get { return _held; }
        }
        public Card() { }
        
        public void Hold(bool? hold = null)
        {
            _held = hold.HasValue ? hold.Value : !_held;
        }
    }
   
    public enum Suit
    {
        Heart, // srdce 
        Spade, // piky
        Club, // žaludy
        Diamond // káry
    }
}
