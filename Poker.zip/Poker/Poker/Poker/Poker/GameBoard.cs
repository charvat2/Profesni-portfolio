﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Poker
{
    //herní plocha
    public partial class GameBoard : Form
    {
        IDeck _deckofcards;
        decimal _balance = 0M;
        decimal _bet = 10M;
        KeyboardHook _kbd = new KeyboardHook();
        List<Prize> Prizes = new List<Prize>
        {
           //list výher(čím lepší kombinace tím lepší výhra)
            new Prize
            {
                Name = "ROYAL FLUSH", // cista vysoka postupka
                Multiplier = 800
            },
            new Prize
            {
                Name = "STRAIGHT FLUSH", // cista postupka
                Multiplier = 50
            },
            new Prize
            {
                Name = "4 ACES", // 4 esa
                Multiplier = 80
            },
            new Prize
            {
                Name = "4 2s, 3s, 4s", 
                Multiplier = 40
            },
            new Prize
            {
                Name = "4 5s THRU KINGS", // 4 pětky až krále
                Multiplier = 25
            },
            new Prize
            {
                Name = "FULL HOUSE", // kombinace trojice a dvojice
                Multiplier = 8
            },
            new Prize
            {
                Name = "FLUSH", // petice stejne barvy
                Multiplier = 5
            },
            new Prize
            {
                Name = "STRAIGHT", // postupka libovolne barvy
                Multiplier = 4
            },
            new Prize
            {
                Name = "3 OF A KIND", // trojice
                Multiplier = 3
            },
            new Prize
            {
                Name = "TWO PAIR", // dva pary
                Multiplier = 2
            },
            new Prize
            {
                Name = "JACKS OR BETTER", // 2x J nebo vyšší
                Multiplier = 1
            }
        };
        // váš balanc peněz
        decimal balance
        {
            get { return _balance; }
            set { _balance = value; labelDynamicBalance.Text = _balance.ToString("c"); }
        }
        //sazka
        decimal bet
        {
            get { return _bet; }
            set {
                _bet = value;
                labelDynamicBet.Text = _bet.ToString("N");
                var n = listViewPrizes.Items.Cast<ListViewItem>().Select(r => r.SubItems).SelectMany(q => q.Cast<ListViewItem.ListViewSubItem>());
                foreach (var b in n)
                {
                    b.BackColor = Color.MidnightBlue;
                }
                foreach (ListViewItem it in listViewPrizes.Items)
                {
                    var b = Convert.ToInt32(_bet / 10);
                    it.SubItems[b].BackColor = Color.Red;
                }
            }
        }
        //herní plocha
        public GameBoard()
        {
            InitializeComponent();
            balance = 5000;
            _deckofcards = new Deck();
            _kbd.KeyUp += _kbd_KeyUp;
        }
        //načítání herní plochy
        private void GameBoard_Load(object sender, EventArgs e)
        {
            _kbd.Install();
            cardHand1.HandComplete += CardHand1_HandComplete;
            cardHand1.StartOfHand += CardHand1_StartOfHand;
            cardHand1.HandDealt += CardHand1_HandDealt;
            foreach (Prize p in Prizes)
            {
                var b = new ListViewItem(p.Name) {
                    Tag = $"_m{p.Name.Replace(" ","")}",
                    UseItemStyleForSubItems = false
                };
                b.SubItems.Add(string.Format("{0:C0}", (p.Multiplier * 10)), Color.White, Color.Red, null);
                b.SubItems.Add(string.Format("{0:C0}", (p.Multiplier * 20)));
                b.SubItems.Add(string.Format("{0:C0}", (p.Multiplier * 30)));
                b.SubItems.Add(string.Format("{0:C0}", (p.Multiplier * 40)));
                b.SubItems.Add(string.Format("{0:C0}", (p.Multiplier * 50)));
                listViewPrizes.Items.Add(b);
            }
        }
        private void _kbd_KeyUp(KeyboardHook.VKeys key)
        {
            if (ActiveForm == this)
            {
                switch (key)
                {
                    // ovladani
                    case KeyboardHook.VKeys.RETURN:
                        if (!cardHand1.IsInitialized)
                        {
                            cardHand1.Initialize(_deckofcards);
                        }
                        else
                        {
                            cardHand1.Deal();
                        }
                        break;
                        // F1, F2 ... zvyšování a snižování sázky
                    case KeyboardHook.VKeys.F1:
                        if (!cardHand1.IsInitialized || cardHand1.EndStage)
                            bet = 10M;
                        break;
                    case KeyboardHook.VKeys.F2:
                        if (!cardHand1.IsInitialized || cardHand1.EndStage)
                            bet = 20M;
                        break;
                    case KeyboardHook.VKeys.F3:
                        if (!cardHand1.IsInitialized || cardHand1.EndStage)
                            bet = 30M;
                        break;
                    case KeyboardHook.VKeys.F4:
                        if (!cardHand1.IsInitialized || cardHand1.EndStage)
                            bet = 40M;
                        break;
                    case KeyboardHook.VKeys.F5:
                        if (!cardHand1.IsInitialized || cardHand1.EndStage)
                            bet = 50M;
                        break;
                        //čísla 1 až 5 uzamykání karet
                    case KeyboardHook.VKeys.NUMPAD1:
                    case KeyboardHook.VKeys.KEY_1:
                        cardHand1.HoldCard(1);
                        break;
                    case KeyboardHook.VKeys.NUMPAD2:
                    case KeyboardHook.VKeys.KEY_2:
                        cardHand1.HoldCard(2);
                        break;
                    case KeyboardHook.VKeys.NUMPAD3:
                    case KeyboardHook.VKeys.KEY_3:
                        cardHand1.HoldCard(3);
                        break;
                    case KeyboardHook.VKeys.NUMPAD4:
                    case KeyboardHook.VKeys.KEY_4:
                        cardHand1.HoldCard(4);
                        break;
                    case KeyboardHook.VKeys.NUMPAD5:
                    case KeyboardHook.VKeys.KEY_5:
                        cardHand1.HoldCard(5);
                        break;
                }
            }
        }
        private void CardHand1_HandDealt(object sender, EventArgs e)
        {           
        }
        //začátek hry
        private void CardHand1_StartOfHand(object sender, EventArgs e)
        {
           // výhry
            var p = listViewPrizes.Items.Cast<ListViewItem>();
            foreach (ListViewItem n in p)
            {
                n.ForeColor = Color.White;
            }
            labelDynamicResult.Text = string.Empty;
            labelDynamicWin.Text = "0.00";
           
            balance -= _bet;
        }
        //konec kola, zobrazení výhry
        private void CardHand1_HandComplete(object sender, CardHand.HandCompleteEventArgs e)
        {
            ListViewItem winnerPrize;
            // herní logika
            //distinct metoda - vrátí odlišné prvky ze sekvences
            Suit[] allSuits = e.Hand.Select(r => r.Suit).Distinct().ToArray();
            int[] seq = e.Hand.Select(r => r.Ordinal).ToArray().OrderBy(i => i).ToArray();
            var fourofakind = seq.GroupBy(f => f).Where(n => n.Count() == 4).Select(p => p.First()).ToArray();
            var threeofakind = seq.GroupBy(f => f).Where(n => n.Count() == 3).Select(p => p.First()).ToArray();
            var pairs = seq.GroupBy(f => f).Where(n => n.Count() == 2).Select(p => p.First()).ToArray();
            if (allSuits.Length == 1)
            {
               
                if (seq.IsSequential())
                {
                    
                    if (seq[0] == 10 && seq[4] == 14)
                    {
                      // kombinace karet  
                        labelDynamicResult.Text = "ROYAL FLUSH";
                        labelDynamicWin.Text = (_bet * 800).ToString("c");
                        balance += _bet * 800;
                        winnerPrize = listViewPrizes.Items.Cast<ListViewItem>().Where(r => r.Tag.ToString() == "_mROYALFLUSH").FirstOrDefault();
                        winnerPrize.ForeColor = Color.Yellow;
                        return;
                    }
                    labelDynamicResult.Text = "STRAIGHT FLUSH";
                    winnerPrize = listViewPrizes.Items.Cast<ListViewItem>().Where(r => r.Tag.ToString() == "_mSTRAIGHTFLUSH").FirstOrDefault();
                    winnerPrize.ForeColor = Color.Red;
                    labelDynamicWin.Text = (_bet * 50).ToString("c");
                    balance += _bet * 50;
                    return;
                }
            }
            //kontrola kombinací
            // cast - přetypování 
            if (fourofakind.Length > 0)
            {
                if (fourofakind.Contains(2) || fourofakind.Contains(3) || fourofakind.Contains(4))
                {
                    labelDynamicResult.Text = "4 2s, 3s, 4s";
                    winnerPrize = listViewPrizes.Items.Cast<ListViewItem>().Where(r => r.Tag.ToString() == "_m42s,3s,4s").FirstOrDefault();
                    winnerPrize.ForeColor = Color.Red;
                    labelDynamicWin.Text = (_bet * 40).ToString("c");
                    balance += _bet * 40;
                    return;
                }
                if (fourofakind.Contains(5) || fourofakind.Contains(6) || fourofakind.Contains(7) || fourofakind.Contains(8) || fourofakind.Contains(9) || fourofakind.Contains(10) || fourofakind.Contains(11) || fourofakind.Contains(12) || fourofakind.Contains(13))
                {
                    labelDynamicResult.Text = "4 5s THRU KINGS";
                    winnerPrize = listViewPrizes.Items.Cast<ListViewItem>().Where(r => r.Tag.ToString() == "_m45sTHRUKINGS").FirstOrDefault();
                    winnerPrize.ForeColor = Color.Red;
                    labelDynamicWin.Text = (_bet * 25).ToString("c");
                    balance += _bet * 25;
                    return;
                }
            }
            if (threeofakind.Length > 0 && pairs.Length > 0)
            {
                labelDynamicResult.Text = "FULL HOUSE";
                winnerPrize = listViewPrizes.Items.Cast<ListViewItem>().Where(r => r.Tag.ToString() == "_mFULLHOUSE").FirstOrDefault();
                winnerPrize.ForeColor = Color.Red;
                labelDynamicWin.Text = (_bet * 8).ToString("c");
                balance += _bet * 8;
                return;
            }
            if (allSuits.Length == 1 && !seq.IsSequential())
            {
                labelDynamicResult.Text = "FLUSH";
                winnerPrize = listViewPrizes.Items.Cast<ListViewItem>().Where(r => r.Tag.ToString() == "_mFLUSH").FirstOrDefault();
                winnerPrize.ForeColor = Color.Red;
                labelDynamicWin.Text = (_bet * 5).ToString("c");
                balance += _bet * 5;
                return;
            }
            if (seq.IsSequential())
            {
                labelDynamicResult.Text = "STRAIGHT";
                winnerPrize = listViewPrizes.Items.Cast<ListViewItem>().Where(r => r.Tag.ToString() == "_mSTRAIGHT").FirstOrDefault();
                winnerPrize.ForeColor = Color.Red;
                labelDynamicWin.Text = (_bet * 4).ToString("c");
                balance += _bet * 4;
                return;
            }
            if (threeofakind.Length > 0)
            {
                labelDynamicResult.Text = "3 OF A KIND";
                winnerPrize = listViewPrizes.Items.Cast<ListViewItem>().Where(r => r.Tag.ToString() == "_m3OFAKIND").FirstOrDefault();
                winnerPrize.ForeColor = Color.Red;
                labelDynamicWin.Text = (_bet * 3).ToString("c");
                balance += _bet * 3;
                return;
            }
            if (pairs.Length > 0)
            {
                if (pairs.Length == 2)
                {
                    labelDynamicResult.Text = "TWO PAIR";
                    winnerPrize = listViewPrizes.Items.Cast<ListViewItem>().Where(r => r.Tag.ToString() == "_mTWOPAIR").FirstOrDefault();
                    winnerPrize.ForeColor = Color.Red;
                    labelDynamicWin.Text = (_bet * 2).ToString("c");
                    balance += _bet * 2;
                    return;
                }
                else if (pairs.Length == 1)
                {
                    if (pairs.Contains(11) || pairs.Contains(12) || pairs.Contains(13) || pairs.Contains(14))
                    {
                        labelDynamicResult.Text = "JACKS OR BETTER";
                        winnerPrize = listViewPrizes.Items.Cast<ListViewItem>().Where(r => r.Tag.ToString() == "_mJACKSORBETTER").FirstOrDefault();
                        winnerPrize.ForeColor = Color.Red;
                        labelDynamicWin.Text = (_bet * 1).ToString("c");
                        balance += _bet * 1;
                        return;
                    }
                }
            }
           //prohra
            labelDynamicResult.Text = "HRÁT ZNOVU";
        }
        private void listViewPrizes_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            
            if (e.IsSelected)
                e.Item.Selected = false;
        }
    }
}

